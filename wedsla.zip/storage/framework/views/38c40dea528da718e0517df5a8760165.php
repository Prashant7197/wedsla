
<?php $__env->startSection('bodycontent'); ?>
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Feedbacks </span> </h4>

        <!-- Basic Bootstrap Table -->
        <div class="card">
            <h5 class="card-header">Feedbacks</h5>
            <?php if(session('msg')): ?>
                <div class="alert y-2 alert-primary alert-dismissible" role="alert">
                    <?php echo e(session('msg')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive text-nowrap">
                <table class="table table-striped table-hover">
                    <caption class="ms-4">
                        List of Feedbacks
                    </caption>
                    <thead>
                        <tr>
                            <th>Name <br/>Description</th>
                            <th>Image</th>
                            <th>Feedback</th>
                            <th>Status</th>

                            <th>Actions</th>
                        </tr>
                    </thead>
                    <?php if($feedbacks->count() > 0): ?>
                        <tbody class="table-border-bottom-0">
                            <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                        <strong><?php echo e($feedback->name); ?></strong><br /><?php echo e($feedback->description); ?>

                                    </td>
                                    <td>
                                        <img src="/images/feedback/<?php echo e($feedback->profile); ?>" class="img-fluid "
                                            style="max-height:100px;" />
                                    </td>
                                    <td style="font-size:14px;"><?php echo e(substr($feedback->feedback,0,50)); ?>...</td>
                                    <td>
                                        <?php if($feedback->status): ?>
                                            <span class="badge bg-label-primary me-1">Active</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Disabled</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">

                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('feedback.edit', $feedback->id)); ?>"><i
                                                        class="bx bx-edit-alt me-1"></i> Edit</a>

                                                <form action="<?php echo e(route('feedback.destroy', $feedback->id)); ?>"
                                                    method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="dropdown-item" type="submit"><i
                                                            class="bx bx-trash me-1"></i> Delete</a>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <!--/ Basic Bootstrap Table -->

        <hr class="my-5" />

    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Client\Wedsla\wedsla\resources\views/admin/feedback/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>
    <script>
        document.getElementById("aboutnav").classList.add('active');
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">

    <section class="hero-wrap hero-wrap-2 ftco-degree-bg js-fullheight"
        style="background-image: url('/images/aboutusbg.jpg');" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate pb-5 text-center">
                    <p class="breadcrumbs"><span class="mr-2"><a href="/">Home <i
                                    class="ion-ios-arrow-forward"></i></a></span> <span>About us <i
                                class="ion-ios-arrow-forward"></i></span></p>
                    <h1 class="mb-3 bread"
                        style="font-family: 'Abril Fatface', cursive;
            font-size: 60px;color:red;">About Us</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="ftco-section ftco-no-pb">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center"
                    style="background-image: url(https://images.pexels.com/photos/306066/pexels-photo-306066.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);">
                </div>
                <div class="col-md-6 wrap-about py-md-5 ftco-animate">
                    <div class="heading-section p-md-5">
                        <h2 class="mb-4">Beyond your expectations</h2>

                        <p>‘Wedsla Pvt. Ltd.’ gives key event arranging and innovative conveyance of gatherings and
                            events for functions including Wedding, Anniversary, Birthday Party, Ring Ceremony, Business
                            Party, Seminar and many more Parties<b>.</b></p>

                        <p>Wedsla provide facilities for book your lawn in simple way at Affordable price. we insure for
                            fully Hassle free asured booking and save your time and money<b>.</b> </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="ftco-section testimony-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <span class="subheading">Testimonial</span>
                    <h2 class="mb-3">Happy Clients</h2>
                </div>
            </div>
            <div class="row ftco-animate">
                <div class="col-md-12">
                    <div class="carousel-testimony owl-carousel ftco-owl">
                        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="testimony-wrap py-4">
                                    <div class="text">
                                        <p class="mb-4"><?php echo e($feedback->feedback); ?></p>
                                        <div class="d-flex align-items-center">
                                            <div class="user-img"
                                                style="background-image: url(/images/feedback/<?php echo e($feedback->profile); ?>)">
                                            </div>
                                            <div class="pl-3">
                                                <p class="name"><?php echo e($feedback->name); ?></p>
                                                <span class="position"><?php echo e($feedback->description); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Client\Wedsla\wedsla\resources\views/about.blade.php ENDPATH**/ ?>

<?php $__env->startSection('bodycontent'); ?>
    <div class="container-xl px-4 mt-4">


        <div class="row">
            <div class="col-xl-4">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php elseif(session('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="card mb-4 mb-xl-0">
                    <div class="card-header">Profile Picture</div>
                    <div class="card-body text-center">

                        <?php if(Auth::guard('vendor')->user()->profile == null): ?>
                            <img class="img-account-profile rounded-circle mb-2 img-fluid"
                                src="http://bootdey.com/img/Content/avatar/avatar1.png" alt>
                        <?php else: ?>
                            <img class="img-account-profile rounded-circle mb-2 img-fluid"
                                src="/images/vendor/<?php echo e(Auth::guard('vendor')->user()->profile); ?>" alt>
                        <?php endif; ?>
                        <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
                        <form action="/vendor/update_profile" enctype="multipart/form-data" id="profile_image" method="POST"
                            style="display: none;">
                            <?php echo csrf_field(); ?>
                            <input type="file" id="change_profile" name="profile" onchange="document.getElementById('profile_image').submit()">
                        </form>
                        <button class="btn btn-primary" onclick="document.getElementById('change_profile').click();"
                            type="button">Upload new image</button>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">

                <div class="card mb-4">
                    <div class="card-header">Account Details</div>
                    <div class="card-body">
                        <form action="/vendor/update" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row gx-3 mb-3">

                                <div class="col-md-12">
                                    <label class="small mb-1" for="inputFirstName">Full Name</label>
                                    <input class="form-control" id="inputFirstName" type="text" name="name"
                                        placeholder="Enter your first name" value="<?php echo e(Auth::guard('vendor')->user()->name); ?>">
                                </div>


                            </div>

                            

                            <div class="mb-3">
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <textarea class="form-control" name="address" id="address" rows="3"><?php echo e(Auth::guard('vendor')->user()->address); ?></textarea>
                                </div>

                            </div>

                            <div class="row gx-3 mb-3">

                                <div class="col-md-6">
                                    <label class="small mb-1" for="inputPhone">Phone number</label>
                                    <input class="form-control" id="inputPhone" type="tel" name="phone"
                                        placeholder="Enter your phone number" value="<?php echo e(Auth::guard('vendor')->user()->contact); ?>">
                                </div>

                                <div class="col-md-6">
                                    <label class="small mb-1" for="email">Email</label>
                                    <input class="form-control" id="email" type="text" name="email" disabled
                                        placeholder="Enter your Email" value="<?php echo e(Auth::guard('vendor')->user()->email); ?>">
                                </div>
                            </div>

                            <button class="btn btn-primary" type="submit">Save changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.vendorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Client\Wedsla\wedsla\resources\views/vendor/profile.blade.php ENDPATH**/ ?>

<?php $__env->startSection('bodycontent'); ?>
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Booking </span> </h4>

        <!-- Basic Bootstrap Table -->
        <div class="card">
            <h5 class="card-header">Booking</h5>
            <?php if(session('msg')): ?>
                <div class="alert y-2 alert-primary alert-dismissible" role="alert">
                    <?php echo e(session('msg')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive text-nowrap">
                <table class="table table-striped table-hover">
                    <caption class="ms-4">
                        List of Booking
                    </caption>
                    <thead>
                        <tr>
                            <th>Name<br /> Email, Contact</th>
                            <th>Lawn (Locality)<br/> Lawn Contact </th>

                            <th>Booking for</th>

                            <th>Booking at</th>
                        </tr>
                    </thead>
                    <?php if($bookings->count() > 0): ?>
                        <tbody class="table-border-bottom-0">
                            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i>
                                        <strong><?php echo e($booking->name); ?></strong><br />
                                        <?php echo e($booking->email); ?><br /><?php echo e($booking->mobile); ?>

                                    </td>
                                    <td>
                                        <?php echo e($booking->lawn_name); ?><br/>(<?php echo e($booking->locality); ?>)
                                        <br/>
                                        <?php echo e($booking->lawn_contact); ?>

                                       
                                    </td>
<td><?php echo e($booking->booking_date); ?><br /><?php echo e(substr($booking->booking_notes, 0, 50) . '...'); ?></td>

                                    <td><?php echo e($booking->created_at); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    <?php endif; ?>
                </table>
            </div>
        </div>
        <!--/ Basic Bootstrap Table -->

        <hr class="my-5" />

    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.agentlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Client\Wedsla\wedsla\resources\views/agent/booking.blade.php ENDPATH**/ ?>
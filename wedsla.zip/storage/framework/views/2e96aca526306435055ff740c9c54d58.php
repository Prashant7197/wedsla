
<?php $__env->startSection('bodycontent'); ?>
    <!-- Content -->
    <div class="container-xl px-4 mt-4">

      
        <div class="row">
            <div class="col-lg-12">

                <div class="card card-header-actions mb-4">
                    <div class="card-header">
                        Notifications
                       
                    </div>
                    <div class="card-body">
                        
                    </div>
                </div>

                
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.agentlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Client\Wedsla\wedsla\resources\views/agent/notification.blade.php ENDPATH**/ ?>